**LazyLibrarian**

LazyLibrarian is a program to follow authors and grab metadata for all your digital reading needs.
It uses a combination of Goodreads Librarything and optionally GoogleBooks as sources for author info and book info.
